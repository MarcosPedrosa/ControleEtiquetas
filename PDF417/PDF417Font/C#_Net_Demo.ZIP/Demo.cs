using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Demo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmDemo : System.Windows.Forms.Form
	{
		private MW6PDF417.Font PDF417FontObj = new MW6PDF417.Font();
		private System.Drawing.Printing.PrintDocument printDocument1;
		internal System.Windows.Forms.Button btnDisplay;
		internal System.Windows.Forms.CheckBox chkTruncateSymbol;
		internal System.Windows.Forms.CheckBox chkHandleTilde;
		internal System.Windows.Forms.Label lblMode;
		internal System.Windows.Forms.Label lblCols;
		internal System.Windows.Forms.ComboBox cbxECLevel;
		internal System.Windows.Forms.Label lblSecurity;
		internal System.Windows.Forms.TextBox txtMessage;
		internal System.Windows.Forms.Label lblMessage;
		internal System.Windows.Forms.Button btnPrint;
		internal System.Drawing.Printing.PrintDocument printDocument2;
		internal System.Windows.Forms.TextBox txtCols;
		internal System.Windows.Forms.TextBox txtRows;
		internal System.Windows.Forms.ComboBox cbxFontSize;
		internal System.Windows.Forms.Label lblFontSize;
		internal System.Windows.Forms.ComboBox cbxFontName;
		internal System.Windows.Forms.Label lblFontName;
		internal System.Windows.Forms.ComboBox cbxMode;
		internal System.Windows.Forms.Label lblRows;
		internal System.Windows.Forms.TextBox txtPDF417;
		internal System.Windows.Forms.Button btnExit;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmDemo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.printDocument1 = new System.Drawing.Printing.PrintDocument();
			this.btnDisplay = new System.Windows.Forms.Button();
			this.chkTruncateSymbol = new System.Windows.Forms.CheckBox();
			this.chkHandleTilde = new System.Windows.Forms.CheckBox();
			this.lblMode = new System.Windows.Forms.Label();
			this.lblCols = new System.Windows.Forms.Label();
			this.cbxECLevel = new System.Windows.Forms.ComboBox();
			this.lblSecurity = new System.Windows.Forms.Label();
			this.txtMessage = new System.Windows.Forms.TextBox();
			this.lblMessage = new System.Windows.Forms.Label();
			this.btnPrint = new System.Windows.Forms.Button();
			this.printDocument2 = new System.Drawing.Printing.PrintDocument();
			this.txtCols = new System.Windows.Forms.TextBox();
			this.txtRows = new System.Windows.Forms.TextBox();
			this.cbxFontSize = new System.Windows.Forms.ComboBox();
			this.lblFontSize = new System.Windows.Forms.Label();
			this.cbxFontName = new System.Windows.Forms.ComboBox();
			this.lblFontName = new System.Windows.Forms.Label();
			this.cbxMode = new System.Windows.Forms.ComboBox();
			this.lblRows = new System.Windows.Forms.Label();
			this.txtPDF417 = new System.Windows.Forms.TextBox();
			this.btnExit = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// printDocument1
			// 
			this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
			// 
			// btnDisplay
			// 
			this.btnDisplay.Location = new System.Drawing.Point(408, 16);
			this.btnDisplay.Name = "btnDisplay";
			this.btnDisplay.Size = new System.Drawing.Size(104, 32);
			this.btnDisplay.TabIndex = 29;
			this.btnDisplay.Text = "Display PDF417";
			this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
			// 
			// chkTruncateSymbol
			// 
			this.chkTruncateSymbol.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.chkTruncateSymbol.Location = new System.Drawing.Point(16, 176);
			this.chkTruncateSymbol.Name = "chkTruncateSymbol";
			this.chkTruncateSymbol.Size = new System.Drawing.Size(128, 16);
			this.chkTruncateSymbol.TabIndex = 24;
			this.chkTruncateSymbol.Text = "Truncate Symbol";
			// 
			// chkHandleTilde
			// 
			this.chkHandleTilde.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.chkHandleTilde.Location = new System.Drawing.Point(16, 144);
			this.chkHandleTilde.Name = "chkHandleTilde";
			this.chkHandleTilde.Size = new System.Drawing.Size(128, 16);
			this.chkHandleTilde.TabIndex = 22;
			this.chkHandleTilde.Text = "Process Tilde";
			// 
			// lblMode
			// 
			this.lblMode.Location = new System.Drawing.Point(16, 120);
			this.lblMode.Name = "lblMode";
			this.lblMode.Size = new System.Drawing.Size(72, 16);
			this.lblMode.TabIndex = 30;
			this.lblMode.Text = "Mode";
			// 
			// lblCols
			// 
			this.lblCols.Location = new System.Drawing.Point(16, 88);
			this.lblCols.Name = "lblCols";
			this.lblCols.Size = new System.Drawing.Size(56, 16);
			this.lblCols.TabIndex = 28;
			this.lblCols.Text = "Columns";
			// 
			// cbxECLevel
			// 
			this.cbxECLevel.Items.AddRange(new object[] {
															"Level 0",
															"Level 1",
															"Level 2",
															"Level 3",
															"Level 4",
															"Level 5",
															"Level 6",
															"Level 7",
															"Level 8"});
			this.cbxECLevel.Location = new System.Drawing.Point(128, 32);
			this.cbxECLevel.Name = "cbxECLevel";
			this.cbxECLevel.Size = new System.Drawing.Size(128, 21);
			this.cbxECLevel.TabIndex = 17;
			this.cbxECLevel.SelectedIndex = 2;
			// 
			// lblSecurity
			// 
			this.lblSecurity.Location = new System.Drawing.Point(16, 40);
			this.lblSecurity.Name = "lblSecurity";
			this.lblSecurity.Size = new System.Drawing.Size(120, 16);
			this.lblSecurity.TabIndex = 23;
			this.lblSecurity.Text = "Error Correction Level";
			// 
			// txtMessage
			// 
			this.txtMessage.Location = new System.Drawing.Point(128, 8);
			this.txtMessage.Name = "txtMessage";
			this.txtMessage.Size = new System.Drawing.Size(248, 20);
			this.txtMessage.TabIndex = 16;
			this.txtMessage.Text = "1234";
			// 
			// lblMessage
			// 
			this.lblMessage.Location = new System.Drawing.Point(16, 8);
			this.lblMessage.Name = "lblMessage";
			this.lblMessage.Size = new System.Drawing.Size(56, 16);
			this.lblMessage.TabIndex = 19;
			this.lblMessage.Text = "Message";
			// 
			// btnPrint
			// 
			this.btnPrint.Location = new System.Drawing.Point(408, 104);
			this.btnPrint.Name = "btnPrint";
			this.btnPrint.Size = new System.Drawing.Size(104, 32);
			this.btnPrint.TabIndex = 31;
			this.btnPrint.Text = "Print PDF417";
			this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
			// 
			// txtCols
			// 
			this.txtCols.Location = new System.Drawing.Point(128, 88);
			this.txtCols.Name = "txtCols";
			this.txtCols.Size = new System.Drawing.Size(128, 20);
			this.txtCols.TabIndex = 20;
			this.txtCols.Text = "3";
			// 
			// txtRows
			// 
			this.txtRows.Location = new System.Drawing.Point(128, 64);
			this.txtRows.Name = "txtRows";
			this.txtRows.Size = new System.Drawing.Size(128, 20);
			this.txtRows.TabIndex = 18;
			this.txtRows.Text = "2";
			// 
			// cbxFontSize
			// 
			this.cbxFontSize.Items.AddRange(new object[] {
															 "6",
															 "7",
															 "8",
															 "9",
															 "10",
															 "11",
															 "12",
															 "14",
															 "16"});
			this.cbxFontSize.Location = new System.Drawing.Point(128, 224);
			this.cbxFontSize.Name = "cbxFontSize";
			this.cbxFontSize.Size = new System.Drawing.Size(128, 21);
			this.cbxFontSize.TabIndex = 27;
			this.cbxFontSize.SelectedIndex = 2;
			// 
			// lblFontSize
			// 
			this.lblFontSize.Location = new System.Drawing.Point(16, 224);
			this.lblFontSize.Name = "lblFontSize";
			this.lblFontSize.Size = new System.Drawing.Size(72, 16);
			this.lblFontSize.TabIndex = 35;
			this.lblFontSize.Text = "Font Size";
			// 
			// cbxFontName
			// 
			this.cbxFontName.Items.AddRange(new object[] {
															 "MW6 PDF417R3",
															 "MW6 PDF417R4",
															 "MW6 PDF417R5",
															 "MW6 PDF417R6"});
			this.cbxFontName.Location = new System.Drawing.Point(128, 192);
			this.cbxFontName.Name = "cbxFontName";
			this.cbxFontName.Size = new System.Drawing.Size(128, 21);
			this.cbxFontName.TabIndex = 25;
			this.cbxFontName.SelectedIndex = 0;
			// 
			// lblFontName
			// 
			this.lblFontName.Location = new System.Drawing.Point(16, 200);
			this.lblFontName.Name = "lblFontName";
			this.lblFontName.Size = new System.Drawing.Size(64, 16);
			this.lblFontName.TabIndex = 34;
			this.lblFontName.Text = "Font Name";
			// 
			// cbxMode
			// 
			this.cbxMode.Items.AddRange(new object[] {
														 "Binary",
														 "Text",
														 "Auto"});
			this.cbxMode.Location = new System.Drawing.Point(128, 112);
			this.cbxMode.Name = "cbxMode";
			this.cbxMode.Size = new System.Drawing.Size(128, 21);
			this.cbxMode.TabIndex = 21;
			this.cbxMode.SelectedIndex = 2;
			// 
			// lblRows
			// 
			this.lblRows.Location = new System.Drawing.Point(16, 64);
			this.lblRows.Name = "lblRows";
			this.lblRows.Size = new System.Drawing.Size(72, 16);
			this.lblRows.TabIndex = 26;
			this.lblRows.Text = "Rows";
			// 
			// txtPDF417
			// 
			this.txtPDF417.Location = new System.Drawing.Point(16, 256);
			this.txtPDF417.Multiline = true;
			this.txtPDF417.Name = "txtPDF417";
			this.txtPDF417.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.txtPDF417.Size = new System.Drawing.Size(512, 152);
			this.txtPDF417.TabIndex = 33;
			this.txtPDF417.Text = "";
			this.txtPDF417.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(408, 184);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(104, 32);
			this.btnExit.TabIndex = 32;
			this.btnExit.Text = "Exit";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// frmDemo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(552, 422);
			this.Controls.Add(this.chkTruncateSymbol);
			this.Controls.Add(this.chkHandleTilde);
			this.Controls.Add(this.lblMode);
			this.Controls.Add(this.lblCols);
			this.Controls.Add(this.cbxECLevel);
			this.Controls.Add(this.lblSecurity);
			this.Controls.Add(this.txtMessage);
			this.Controls.Add(this.lblMessage);
			this.Controls.Add(this.btnPrint);
			this.Controls.Add(this.txtCols);
			this.Controls.Add(this.txtRows);
			this.Controls.Add(this.cbxFontSize);
			this.Controls.Add(this.lblFontSize);
			this.Controls.Add(this.cbxFontName);
			this.Controls.Add(this.lblFontName);
			this.Controls.Add(this.cbxMode);
			this.Controls.Add(this.lblRows);
			this.Controls.Add(this.txtPDF417);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnDisplay);
			this.Name = "frmDemo";
			this.Text = "PDF417 Font Demo";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmDemo());
		}

		private void btnPrint_Click(object sender, System.EventArgs e)
		{
			// Message 
			string Message = txtMessage.Text;

			// 0 for Binary Mode, 1 for Text Mode, 2 for Auto mode
			int Mode = cbxMode.SelectedIndex;

			// Error Correction Level (0 - 8)
			int ECLevel = cbxECLevel.SelectedIndex;

			// PDF417 Rows (3 - 90)
			int Rows = System.Convert.ToInt16(txtRows.Text);

			// PDF417 Columns (3 - 30)
			int Columns = System.Convert.ToInt16(txtCols.Text);

			// Truncate symbol or not?
			bool TruncateSymbol = chkTruncateSymbol.Checked;

			// Handle tilde or not? 
			bool HandleTilde = chkHandleTilde.Checked;

			// Encode data using PDF417
			PDF417FontObj.Encode(Message, Mode, ECLevel, Rows, Columns, TruncateSymbol, HandleTilde);

			// Print PDF417 barcode using PDF417 font
			printDocument1.Print();
		}

		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			// how many rows?
			int RowCount = PDF417FontObj.GetRows();

			// how many characters in one row?
			int ColCount = PDF417FontObj.GetCols();

			SolidBrush sb = new SolidBrush(Color.Black);
			Font fn = new Font(cbxFontName.Text, System.Convert.ToInt16(cbxFontSize.Text), GraphicsUnit.Pixel);
			for (int i = 0; i <= (RowCount - 1); i++)
				e.Graphics.DrawString(PDF417FontObj.GetRowStringAt(i), fn, sb, 10, 10 + i * fn.GetHeight());

			sb.Dispose();
			fn.Dispose();
		}

		private void btnDisplay_Click(object sender, System.EventArgs e)
		{
			// Message 
			string Message = txtMessage.Text;

			// 0 for Binary Mode, 1 for Text Mode, 2 for Auto mode
			int Mode = cbxMode.SelectedIndex;

			// Error Correction Level (0 - 8)
			int ECLevel = cbxECLevel.SelectedIndex;

			// PDF417 Rows (3 - 90)
			int Rows = System.Convert.ToInt16(txtRows.Text);

			// PDF417 Columns (3 - 30)
			int Columns = System.Convert.ToInt16(txtCols.Text);

			// Truncate symbol or not?
			bool TruncateSymbol = chkTruncateSymbol.Checked;

			// Handle tilde or not? 
			bool HandleTilde = chkHandleTilde.Checked;

			// Encode data using PDF417
			PDF417FontObj.Encode(Message, Mode, ECLevel, Rows, Columns, TruncateSymbol, HandleTilde);

			// How many rows?
			int RowCount = PDF417FontObj.GetRows();

			// Produce string for PDF417 font
			string EncodedMsg = "" + System.Convert.ToChar(13) + System.Convert.ToChar(10);
			for (int i = 0; i < RowCount; i++)
			{
				EncodedMsg = EncodedMsg + PDF417FontObj.GetRowStringAt(i);
				EncodedMsg = EncodedMsg + System.Convert.ToChar(13) + System.Convert.ToChar(10);
			}

			txtPDF417.Text = "";
			int FontSize = System.Convert.ToInt16(cbxFontSize.Text);
			txtPDF417.Font = new Font(cbxFontName.Text, FontSize, GraphicsUnit.Pixel);
			txtPDF417.Text = EncodedMsg;
		}

		private void btnExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit(); 
		}
	}
}