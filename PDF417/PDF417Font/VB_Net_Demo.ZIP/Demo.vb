Public Class frmDemo
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents txtMessage As System.Windows.Forms.TextBox
    Friend WithEvents lblSecurity As System.Windows.Forms.Label
    Friend WithEvents cbxECLevel As System.Windows.Forms.ComboBox
    Friend WithEvents lblRows As System.Windows.Forms.Label
    Friend WithEvents lblCols As System.Windows.Forms.Label
    Friend WithEvents lblMode As System.Windows.Forms.Label
    Friend WithEvents chkHandleTilde As System.Windows.Forms.CheckBox
    Friend WithEvents chkTruncateSymbol As System.Windows.Forms.CheckBox
    Friend WithEvents cbxMode As System.Windows.Forms.ComboBox
    Friend WithEvents lblFontName As System.Windows.Forms.Label
    Friend WithEvents cbxFontName As System.Windows.Forms.ComboBox
    Friend WithEvents txtPDF417 As System.Windows.Forms.TextBox
    Friend WithEvents lblFontSize As System.Windows.Forms.Label
    Friend WithEvents cbxFontSize As System.Windows.Forms.ComboBox
    Friend WithEvents txtRows As System.Windows.Forms.TextBox
    Friend WithEvents txtCols As System.Windows.Forms.TextBox
    Friend WithEvents btnDisplay As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnPrint = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument
        Me.txtPDF417 = New System.Windows.Forms.TextBox
        Me.lblMessage = New System.Windows.Forms.Label
        Me.txtMessage = New System.Windows.Forms.TextBox
        Me.lblSecurity = New System.Windows.Forms.Label
        Me.cbxECLevel = New System.Windows.Forms.ComboBox
        Me.lblRows = New System.Windows.Forms.Label
        Me.lblCols = New System.Windows.Forms.Label
        Me.lblMode = New System.Windows.Forms.Label
        Me.chkHandleTilde = New System.Windows.Forms.CheckBox
        Me.chkTruncateSymbol = New System.Windows.Forms.CheckBox
        Me.cbxMode = New System.Windows.Forms.ComboBox
        Me.lblFontName = New System.Windows.Forms.Label
        Me.cbxFontName = New System.Windows.Forms.ComboBox
        Me.lblFontSize = New System.Windows.Forms.Label
        Me.cbxFontSize = New System.Windows.Forms.ComboBox
        Me.txtRows = New System.Windows.Forms.TextBox
        Me.txtCols = New System.Windows.Forms.TextBox
        Me.btnDisplay = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(408, 100)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(104, 32)
        Me.btnPrint.TabIndex = 10
        Me.btnPrint.Text = "Print PDF417"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(408, 184)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(104, 32)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Exit"
        '
        'PrintDocument1
        '
        '
        'txtPDF417
        '
        Me.txtPDF417.Location = New System.Drawing.Point(16, 256)
        Me.txtPDF417.Multiline = True
        Me.txtPDF417.Name = "txtPDF417"
        Me.txtPDF417.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtPDF417.Size = New System.Drawing.Size(512, 152)
        Me.txtPDF417.TabIndex = 12
        Me.txtPDF417.Text = ""
        Me.txtPDF417.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblMessage
        '
        Me.lblMessage.Location = New System.Drawing.Point(16, 8)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(56, 16)
        Me.lblMessage.TabIndex = 3
        Me.lblMessage.Text = "Message"
        '
        'txtMessage
        '
        Me.txtMessage.Location = New System.Drawing.Point(128, 8)
        Me.txtMessage.Name = "txtMessage"
        Me.txtMessage.Size = New System.Drawing.Size(248, 20)
        Me.txtMessage.TabIndex = 0
        Me.txtMessage.Text = "1234"
        '
        'lblSecurity
        '
        Me.lblSecurity.Location = New System.Drawing.Point(16, 35)
        Me.lblSecurity.Name = "lblSecurity"
        Me.lblSecurity.Size = New System.Drawing.Size(120, 16)
        Me.lblSecurity.TabIndex = 5
        Me.lblSecurity.Text = "Error Correction Level"
        '
        'cbxECLevel
        '
        Me.cbxECLevel.Items.AddRange(New Object() {"Level 0", "Level 1", "Level 2", "Level 3", "Level 4", "Level 5", "Level 6", "Level 7", "Level 8"})
        Me.cbxECLevel.Location = New System.Drawing.Point(128, 33)
        Me.cbxECLevel.Name = "cbxECLevel"
        Me.cbxECLevel.Size = New System.Drawing.Size(128, 21)
        Me.cbxECLevel.TabIndex = 1
        Me.cbxECLevel.SelectedIndex = 2
        '
        'lblRows
        '
        Me.lblRows.Location = New System.Drawing.Point(16, 62)
        Me.lblRows.Name = "lblRows"
        Me.lblRows.Size = New System.Drawing.Size(72, 16)
        Me.lblRows.TabIndex = 7
        Me.lblRows.Text = "Rows"
        '
        'lblCols
        '
        Me.lblCols.Location = New System.Drawing.Point(16, 89)
        Me.lblCols.Name = "lblCols"
        Me.lblCols.Size = New System.Drawing.Size(56, 16)
        Me.lblCols.TabIndex = 8
        Me.lblCols.Text = "Columns"
        '
        'lblMode
        '
        Me.lblMode.Location = New System.Drawing.Point(16, 116)
        Me.lblMode.Name = "lblMode"
        Me.lblMode.Size = New System.Drawing.Size(72, 16)
        Me.lblMode.TabIndex = 9
        Me.lblMode.Text = "Mode"
        '
        'chkHandleTilde
        '
        Me.chkHandleTilde.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkHandleTilde.Location = New System.Drawing.Point(16, 143)
        Me.chkHandleTilde.Name = "chkHandleTilde"
        Me.chkHandleTilde.Size = New System.Drawing.Size(128, 16)
        Me.chkHandleTilde.TabIndex = 5
        Me.chkHandleTilde.Text = "Process Tilde"
        '
        'chkTruncateSymbol
        '
        Me.chkTruncateSymbol.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkTruncateSymbol.Location = New System.Drawing.Point(16, 170)
        Me.chkTruncateSymbol.Name = "chkTruncateSymbol"
        Me.chkTruncateSymbol.Size = New System.Drawing.Size(128, 16)
        Me.chkTruncateSymbol.TabIndex = 6
        Me.chkTruncateSymbol.Text = "Truncate Symbol"
        '
        'cbxMode
        '
        Me.cbxMode.Items.AddRange(New Object() {"Binary", "Text", "Auto"})
        Me.cbxMode.Location = New System.Drawing.Point(128, 109)
        Me.cbxMode.Name = "cbxMode"
        Me.cbxMode.Size = New System.Drawing.Size(128, 21)
        Me.cbxMode.TabIndex = 4
        Me.cbxMode.SelectedIndex = 2
        '
        'lblFontName
        '
        Me.lblFontName.Location = New System.Drawing.Point(16, 197)
        Me.lblFontName.Name = "lblFontName"
        Me.lblFontName.Size = New System.Drawing.Size(64, 16)
        Me.lblFontName.TabIndex = 13
        Me.lblFontName.Text = "Font Name"
        '
        'cbxFontName
        '
        Me.cbxFontName.Items.AddRange(New Object() {"MW6 PDF417R3", "MW6 PDF417R4", "MW6 PDF417R5", "MW6 PDF417R6"})
        Me.cbxFontName.Location = New System.Drawing.Point(128, 193)
        Me.cbxFontName.Name = "cbxFontName"
        Me.cbxFontName.Size = New System.Drawing.Size(128, 21)
        Me.cbxFontName.TabIndex = 7
        Me.cbxFontName.SelectedIndex = 0
        '
        'lblFontSize
        '
        Me.lblFontSize.Location = New System.Drawing.Point(16, 224)
        Me.lblFontSize.Name = "lblFontSize"
        Me.lblFontSize.Size = New System.Drawing.Size(72, 16)
        Me.lblFontSize.TabIndex = 15
        Me.lblFontSize.Text = "Font Size"
        '
        'cbxFontSize
        '
        Me.cbxFontSize.Items.AddRange(New Object() {"6", "7", "8", "9", "10", "11", "12", "14", "16"})
        Me.cbxFontSize.Location = New System.Drawing.Point(128, 219)
        Me.cbxFontSize.Name = "cbxFontSize"
        Me.cbxFontSize.Size = New System.Drawing.Size(128, 21)
        Me.cbxFontSize.TabIndex = 8
        Me.cbxFontSize.SelectedIndex = 2
        '
        'txtRows
        '
        Me.txtRows.Location = New System.Drawing.Point(128, 59)
        Me.txtRows.Name = "txtRows"
        Me.txtRows.Size = New System.Drawing.Size(128, 20)
        Me.txtRows.TabIndex = 2
        Me.txtRows.Text = "3"
        '
        'txtCols
        '
        Me.txtCols.Location = New System.Drawing.Point(128, 84)
        Me.txtCols.Name = "txtCols"
        Me.txtCols.Size = New System.Drawing.Size(128, 20)
        Me.txtCols.TabIndex = 3
        Me.txtCols.Text = "3"
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(408, 16)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(104, 32)
        Me.btnDisplay.TabIndex = 9
        Me.btnDisplay.Text = "Display PDF417"
        '
        'frmDemo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(544, 422)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.txtCols)
        Me.Controls.Add(Me.txtRows)
        Me.Controls.Add(Me.cbxFontSize)
        Me.Controls.Add(Me.lblFontSize)
        Me.Controls.Add(Me.cbxFontName)
        Me.Controls.Add(Me.lblFontName)
        Me.Controls.Add(Me.cbxMode)
        Me.Controls.Add(Me.chkTruncateSymbol)
        Me.Controls.Add(Me.chkHandleTilde)
        Me.Controls.Add(Me.lblMode)
        Me.Controls.Add(Me.lblCols)
        Me.Controls.Add(Me.lblRows)
        Me.Controls.Add(Me.cbxECLevel)
        Me.Controls.Add(Me.lblSecurity)
        Me.Controls.Add(Me.txtMessage)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.txtPDF417)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnPrint)
        Me.Name = "frmDemo"
        Me.Text = "PDF417 Font Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private PDF417FontObj As MW6PDF417.Font = New MW6PDF417.Font()

    Private Function Check() As Boolean
        Dim ErrMSg As String

        ' do error-check
        On Error GoTo HandleErr
        ErrMSg = ""
        If (Len(txtMessage.Text) = 0) Then
            ErrMSg = "Please enter the message to encode with PDF417."
            ErrMSg = ErrMSg & Chr(13) & Chr(10)
        End If

        If ((CInt(txtRows.Text) > 90) Or (CInt(txtRows.Text) < 3)) Then
            ErrMSg = ErrMSg & "Rows must be between 3 and 90."
            ErrMSg = ErrMSg & Chr(13) & Chr(10)
        End If

        If ((CInt(txtCols.Text) > 30) Or (CInt(txtCols.Text) < 3)) Then
            ErrMSg = ErrMSg & "Columns must be between 3 and 30."
            ErrMSg = ErrMSg & Chr(13) & Chr(10)
        End If

        If (Len(ErrMSg) > 0) Then
            MsgBox(ErrMSg)
            Check = False
            Exit Function
        End If

        Check = True
        Exit Function

HandleErr:
        Check = False

    End Function


    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim Message As String
        Dim Mode As Integer
        Dim ECLevel As Integer
        Dim Rows As Integer
        Dim Columns As Integer
        Dim TruncateSymbol As Boolean
        Dim HandleTilde As Boolean

        If (Not Check()) Then
            Exit Sub
        End If

        ' Message 
        Message = txtMessage.Text

        ' 0 for Binary Mode, 1 for Text Mode, 2 for Auto mode
        Mode = cbxMode.SelectedIndex

        ' Error Correction Level (0 - 8)
        ECLevel = cbxECLevel.SelectedIndex

        ' PDF417 Rows (3 - 90)
        Rows = System.Convert.ToInt16(txtRows.Text)

        ' PDF417 Columns (3 - 30)
        Columns = System.Convert.ToInt16(txtCols.Text)

        ' Truncate symbol or not?
        TruncateSymbol = chkTruncateSymbol.Checked

        ' Handle tilde or not?
        HandleTilde = chkHandleTilde.Checked

        ' Encode data using PDF417
        PDF417FontObj.Encode(Message, Mode, ECLevel, Rows, Columns, TruncateSymbol, HandleTilde)

        ' Print PDF417 barcode using PDF417 font
        PrintDocument1.Print()
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim RowCount As Integer
        Dim ColCount As Integer
        Dim I As Integer
        Dim sb As SolidBrush
        Dim fn As Font
        Dim FontSize As Integer

        ' How many rows?
        RowCount = PDF417FontObj.GetRows()

        ' How many characters in one row?
        ColCount = PDF417FontObj.GetCols()

        sb = New SolidBrush(Color.Black)

        FontSize = System.Convert.ToInt16(cbxFontSize.Text)
        fn = New Font(cbxFontName.Text, FontSize, GraphicsUnit.Pixel)
        For I = 0 To (RowCount - 1)
            e.Graphics.DrawString(PDF417FontObj.GetRowStringAt(I), fn, sb, 10, 10 + I * fn.GetHeight)
        Next I

        sb.Dispose()
        fn.Dispose()
    End Sub

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        Dim Message As String
        Dim Mode As Integer
        Dim ECLevel As Integer
        Dim Rows As Integer
        Dim Columns As Integer
        Dim TruncateSymbol As Boolean
        Dim HandleTilde As Boolean
        Dim RowCount As Integer
        Dim ColCount As Integer
        Dim I As Integer
        Dim EncodedMsg As String
        Dim fn As Font
        Dim FontSize As Integer


        If (Not Check()) Then
            Exit Sub
        End If

        ' Message 
        Message = txtMessage.Text

        ' 0 for Binary Mode, 1 for Text Mode, 2 for Auto mode
        Mode = cbxMode.SelectedIndex

        ' Error Correction Level (0 - 8)
        ECLevel = cbxECLevel.SelectedIndex

        ' PDF417 Rows (3 - 90)
        Rows = System.Convert.ToInt16(txtRows.Text)

        ' PDF417 Columns (3 - 30)
        Columns = System.Convert.ToInt16(txtCols.Text)

        ' Truncate symbol or not?
        TruncateSymbol = chkTruncateSymbol.Checked

        ' Handle tilde or not?
        HandleTilde = chkHandleTilde.Checked

        ' Encode data using PDF417
        PDF417FontObj.Encode(Message, Mode, ECLevel, Rows, Columns, TruncateSymbol, HandleTilde)

        ' How many rows?
        RowCount = PDF417FontObj.GetRows()

        ' How many characters in one row?
        ColCount = PDF417FontObj.GetCols()

        ' Produce string for PDF417 font
        EncodedMsg = "" & vbCrLf
        For I = 1 To RowCount
            EncodedMsg = EncodedMsg & PDF417FontObj.GetRowStringAt(I - 1) & vbCrLf
        Next I

        txtPDF417.Text = ""
        FontSize = System.Convert.ToInt16(cbxFontSize.Text)
        txtPDF417.Font = New Font(cbxFontName.Text, FontSize, GraphicsUnit.Pixel)
        txtPDF417.Text = EncodedMsg

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
End Class
