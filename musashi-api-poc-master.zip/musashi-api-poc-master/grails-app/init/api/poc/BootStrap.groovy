package api.poc

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
