# Esse projeto é apenas uma prova de conceito. 
- Não eh e nem será um projeto que devemos continuar.

# Requisitos
- git
- java SRE 11+ (já deve estar instalado no computador por padrão)

# Instrucoes de uso
### Linux
./gradlew bootRun 
### Ruimdows
gradlew.bat bootRun 

### como Usar?
Pra acessar so precisa fazer uma requisição pra o http://localhost:8080/poc?cFields=2022-04-15 pelo VisualBase

Se a aplicação estiver levantada, da para testar pelo browser. So precisa colocar http://localhost:8080/poc?cFields=2022-04-15 na URL

## Observacoes 
eh necessário que voce esteja conectado a VPN da musashi
