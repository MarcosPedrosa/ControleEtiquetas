package api.poc

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class PocControllerSpec extends Specification implements ControllerUnitTest<PocController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
