''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'
' Image Database Version 2.x.x
'
' Written by L. "Mike" Trivette
' Please send me comments at mtrivette@yahoo.com
'
' Sorry for any code snippets i used and did not give credit.
' I have had som many snippets that I have collected over time. 
' I worked hard on this so please give feedback and credit thats due.
'
' Last Revised 03/10/2005 11:23:00pm EST USA
'
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Whats New:
	* Ability to resize category/preview panes 
	* Fixed bug with importing multiple images 
	* Added slideshow feature
	* Supports single or multiple deletes
	* Revised options form
	* Fixed the copy to clipboard feature
	* Autorename tool is now working (and fast)
	* Show image details in status bar
	* Create new databases ready to use 
	* Ability to compact the database 
	* Ability to choose a new database 
	* Cleaned up the about screen 
	* Revised the optiosn form
	* Added refresh menu option to listview
	* 

Features: 
	* Show images in database as list or thumbnailed
	* Imports single or multiple images into database at one time
	* Stores image data, image type, category, file size, dimestions
	* Exports image from database to HDD
	* Organize pictures into categories
	* Ability to delete images from database
	* Able to cut or copy images from database to clipboard
	* Preview images directly form the application
	* Select all and invert selections fucntion
	* Screens new images for duplicates before importing into database
	* Abilty to remember options and user preferences
	* Option to automatically delete image after importing or exporting
	* Ues GDI to process graphics
	* New about screen
	* New ability to view images in thumbnail form or list
	* Right click on images popup menu
	* Implemented category system for organization
	* Improved speed and performance
	* Abilty to select all or invert slection(s)
	* Implemented config.ini file for setting saves
	* Added options to application
	* User can set the thumbnail size
	* Application can be resized
	* Can show single of multiple image previews
	* Heavily commented source code


Known Bugs:	
	* Slide show not going full screen	

To Do: 
	* Ability to cache thumbnails
	* Add right click menu for categories list
	* Implement "DROP and DRAG" system to ease image organization
	* Optimize the existing all the existing code 	
	* Add more error checking for user input
	* Come up with a better application title. LOL 
	* Make a better looking GUI
	* Create slideshow options


